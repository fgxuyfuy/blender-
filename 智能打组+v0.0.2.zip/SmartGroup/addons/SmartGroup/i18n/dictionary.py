from SmartGroup.common.class_loader.auto_load import preprocess_dictionary

dictionary = {
    "zh_CN": {
        ("Operator", "Create Group"): "创建组",
        ("Operator", "Dissolve Group"): "解散组",
        ("Operator", "Add Selection to Group"): "添加到组",
        ("Operator", "Delete Group"): "删除组",
        ("Operator", "Apply Group"): "应用组",
        ("Operator", "Duplicate Group"): "复制组",
        ("Operator", "Edit Group"): "编辑组",
        ("Operator", "Fix Group"): "修复组",
        ("Operator", "Select All Group Members"): "选择所有组员",
        ("Operator", "Remove From Local View"): "从局部视图移除",
        ("Operator", "Remove Selected Group Members"): "移除选中组员",
        ("Operator", "Use Instance/Non-Instance"): "使用实例/非实例",
        ("Operator", "Exit Edit Mode"): "退出编辑模式",

        ("*", "Smart Group Pie Menu"): "智能打组饼菜单",
        ("*", "SmartGroup"): "智能打组",
        ("*", "Smart Group"): "智能打组",
        ("*", "Edit Setting"): "编辑设置",
        ("*", "Use Local View When Editing a Group"): "编辑组时使用局部视图",
        ("*", "Show Bounds"): "显示边界框",
        ("*", "Bounds Type"): "边界框类型",
        ("*", "Material Override"): "材质覆盖",
        ("*", "Display Settings"): "显示设置",
        ("*", "Hide/Show Group"): "隐藏/显示组",
        ("Operator", "Display as Wire"): "显示为线框",
        ("Operator", "Display as Solid"): "显示为实体",
        ("*", "Status:"): "状态：",
        ("*", "Instance"): "实例",
        ("*", "Non-Instance"): "非实例",

        ("*", "Create a Group with Selected Objects"): "将所选对象创建为组",
        ("*", "Dissolve Selected Groups"): "解散选中的组",
        ("*", "Add Selected Objects to Group"): "将所选物体添加到组",
        ("*", "Delete Selected Groups"): "删除选中的组",
        ("*", "Apply the SmartGroup Modifier and Remove Group Members.(The Group Object will be one Object, instance won't be applied)"): "应用智能打组修改器并移除组成员（组对象会变成一个物体，实例物体不会被应用）",
        ("*", "Duplicate Selected Groups"): "复制选中的组",
        ("*", "Fix Selected Groups(Use it when there are Problems in Materials or Parenting)"): "修复选中的组（当材质或父子关系出现问题时使用）",

        ("*", "Edit active Group"): "编辑活动组",
        ("*", "Exit Edit Mode"): "退出编辑模式",
        ("*", "Select All Group Members"): "选择所有组员",
        ("*", "Remove Selected Objects from Local View"): "从局部视图移除选中物体",
        ("*", "Remove Selected Group Members"): "移除选中组员",
        ("*", "Switch Display Type"): "切换显示类型",
        ("*", "Switch Selected Group Members to Instance/Non-Instance"): "将选中组员切换为实例/非实例",
        ("*", "Groups fixed"): "组已修复",

        ("*", "Selected objects has group, please select objects without group"): "选中的物体中已存在组，请选择没有组的物体",
        ("*", "No group members selected"): "没有选中组员",
        ("*", "No group selected"): "没有选中组",
        ("*", "Group Members instance switched"): "组员实例已切换",
        ("*", "There are objects that are not mesh based, addon won't work properly on these objects"): "存在不是基于网格的物体，插件将无法在这些物体上正常工作",
        ("*", "Active object is not a group"): "活动物体不是组",

        ("*", "a group tool"): "打组工具",
        ("*", "Hide Group"): "隐藏组",
        ("*", "Add Weighted Normal Modifier"): "添加加权法向修改器",
        ("*", "Hide the Group Object when editing the Group"): "编辑组时隐藏组物体",
        ("*", "Show Wireframe when editing the Group"): "编辑组时显示组物体线框",
        ("*", "Default Transparency of the Group Object in editing mode"): "编辑模式中组物体的默认透明度",
        ("*", "Show the Group Object in front of other objects when editing the Group"): "编辑组时将组物显示在其他物体前面",
        ("*", "Add Weighted Normal Modifier when creating the Group"): "创建组时添加加权法向修改器",
        ("*", "KeyMap"): "快捷键",
        ("Operator", "Bilibili"): "哔哩哔哩",

        ("*", "Group's members are not all linked to the scene, operation cancelled."): "组成员中有未链接到场景的物体，操作已取消。",
        ("*", "Apply Other Modifiers"): "应用修改器",
        ("*", "Apply other modifiers on the group objects"): "应用组物体的剩余修改器",
        ("*", "Bounds Types"): "边界框类型",
    }
}

dictionary = preprocess_dictionary(dictionary)

dictionary["zh_HANS"] = dictionary["zh_CN"]
