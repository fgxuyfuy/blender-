import  bpy

from SmartGroup.addons.SmartGroup.operators.EditGroupOperator import EditGroupOperator, ExitEditGroupOperator, \
    RemoveFromLocalViewOperator, SelectAllGroupMembersOperator, RemoveGroupMemberOperator, \
    MembersInstanceSwitchOperator, SwitchDisplayTypeOperator
from SmartGroup.addons.SmartGroup.operators.GroupOperators import CreateGroupOperator, DeleteGroupOperator, ApplyGroupOperator, \
    DissolveGroupOperator, AddSelectionToGroupOperator, DuplicateGroupOperator, FixGroupOperator

class SmartGroupMenu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_pie_menu"
    bl_label = "Smart Group Pie Menu"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        if not context.scene.SG.edit_mode:
            pie.operator(DeleteGroupOperator.bl_idname, icon="TRASH")
            pie.operator(ApplyGroupOperator.bl_idname, icon="MODIFIER_DATA")
            pie.operator(EditGroupOperator.bl_idname, icon="EDITMODE_HLT")
            pie.operator(CreateGroupOperator.bl_idname, icon="LINKED")
            pie.operator(DissolveGroupOperator.bl_idname, icon="UNLINKED")
            pie.operator(AddSelectionToGroupOperator.bl_idname, icon="PLUS")
            pie.operator(DuplicateGroupOperator.bl_idname, icon="DUPLICATE")

            box = pie.box()
            col = box.column(align=True)
            col.operator(FixGroupOperator.bl_idname, icon="MODIFIER_DATA")
            active_obj = context.active_object
            if active_obj and active_obj.SG.is_group:
                col.prop(active_obj, 'show_bounds', text="Show Bounds", icon='CUBE')
                node_group = active_obj.SG.node_group
                col.prop(node_group.nodes['Switch'].inputs['Switch'], 'default_value', text="Material Override", icon='MATERIAL')
                col.prop(node_group.nodes["Set_Material"].inputs['Material'], 'default_value', text="Material")
        else:
            pie.operator(RemoveFromLocalViewOperator.bl_idname, icon='RESTRICT_VIEW_OFF')
            pie.operator(RemoveGroupMemberOperator.bl_idname, icon='REMOVE')
            pie.operator(ExitEditGroupOperator.bl_idname, icon="LOOP_BACK")

            # draw instance status
            if context.active_object:
                box = pie.box()
                row = box.row(align=True)
                row.alignment = 'LEFT'
                row.label(text="Status:", icon='MONKEY')
                status = "Instance" if context.active_object.SG.as_instance else "Non-Instance"
                row.label(text=status)
            else:
                pie.separator()

            pie.operator(SelectAllGroupMembersOperator.bl_idname, icon='RESTRICT_SELECT_OFF')
            pie.operator(AddSelectionToGroupOperator.bl_idname, icon="PLUS")
            pie.operator(MembersInstanceSwitchOperator.bl_idname, icon="OUTLINER_OB_GROUP_INSTANCE", text='Use Instance/Non-Instance')

            box = pie.box()
            col = box.column(align=True)
            col.operator(FixGroupOperator.bl_idname, icon="MODIFIER_DATA")
            col.prop(context.scene.SG.edit_group_object, 'hide_viewport', text="Hide/Show Group", icon='HIDE_OFF')
            col.prop(context.scene.SG.edit_group_object, 'show_wire', text="Show Wire", icon='MESH_CUBE')
            # draw wire/solid switch
            if context.scene.SG.edit_group_object.display_type != "WIRE":
                col.operator(SwitchDisplayTypeOperator.bl_idname, text="Display as Wire", icon="SHADING_WIRE")
            else:
                col.operator(SwitchDisplayTypeOperator.bl_idname, text="Display as Solid", icon="SHADING_SOLID")
            # draw transparency slider
            col.prop(context.scene.SG.edit_group_object, 'color', index=3, text="Transparency", slider=True)
