import bpy

class ObjectPointerProperties(bpy.types.PropertyGroup):
    object_pointer: bpy.props.PointerProperty(type=bpy.types.Object)

class SmartGroupObjectPointerProperties(bpy.types.PropertyGroup):
    is_group: bpy.props.BoolProperty(name = "Is Group", default = False)
    group_member_list: bpy.props.CollectionProperty(name = "Group Member", type=ObjectPointerProperties)
    node_group: bpy.props.PointerProperty(type=bpy.types.NodeTree)
    as_instance: bpy.props.BoolProperty(name = "As Instance", default = False)

class SmartGroupScenePointerProperties(bpy.types.PropertyGroup):
    edit_mode: bpy.props.BoolProperty(name = "Edit Mode", default = False)
    edit_group_object: bpy.props.PointerProperty(type=bpy.types.Object)
    edit_object_show_wire: bpy.props.BoolProperty(name = "Show Wire", default = False)
    edit_object_show_bounds: bpy.props.BoolProperty(name = "Show Bounds", default = False)
    edit_object_show_in_front: bpy.props.BoolProperty(name = "Show In Front", default = False)
    edit_object_alpha: bpy.props.FloatProperty(name = "Alpha", default = 1.0)
    edit_object_display_type: bpy.props.StringProperty(name = "Display Type", default = "TEXTURED")
    scene_color_type:bpy.props.StringProperty(name = "Color Type", default = "OBJECT")
    duplicating:bpy.props.BoolProperty(name = "Duplicating", default = False)
    use_local_view:bpy.props.BoolProperty(name = "Use Local View", default = False)



