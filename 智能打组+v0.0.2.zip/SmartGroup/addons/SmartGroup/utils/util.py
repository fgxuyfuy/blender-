import bpy
from mathutils import Vector

def get_bbox_center(selected_objs):
    '''Get the center of the bounding box of selected objects.
    '''
    # initialize the corners of the bounding box
    min_corner = Vector((float('inf'), float('inf'), float('inf')))
    max_corner = Vector((float('-inf'), float('-inf'), float('-inf')))

    # iterate over all selected objects
    for obj in selected_objs:
        # get the bounding box of the object
        for corner in obj.bound_box:
            # transform the corner to world space
            world_corner = obj.matrix_world @ Vector(corner)

            # update the max/min corners of the bounding box
            min_corner = Vector((min(min_corner.x, world_corner.x),
                                 min(min_corner.y, world_corner.y),
                                 min(min_corner.z, world_corner.z)))
            max_corner = Vector((max(max_corner.x, world_corner.x),
                                 max(max_corner.y, world_corner.y),
                                 max(max_corner.z, world_corner.z)))

    # calculate the center of the bounding box
    bbox_center = (min_corner + max_corner) / 2
    # print("BBox Center:", bbox_center)

    return bbox_center

def new_GeometryNodes_group():
    ''' Create a new empty node group that can be used
        in a GeometryNodes modifier.
    '''
    # create a new node group
    node_group = bpy.data.node_groups.new(name='.SmartGroup', type='GeometryNodeTree')

    # create input and output nodes
    group_input = node_group.nodes.new(type='NodeGroupInput')
    group_input.name = 'Group_Input'
    node_group.interface.new_socket(name='GeometryData', description="", in_out='INPUT',
                                    socket_type='NodeSocketGeometry', parent=None)  # create input socket

    group_output = node_group.nodes.new(type='NodeGroupOutput')
    group_output.name = 'Group_Output'
    node_group.interface.new_socket(name='GeometryData', description="", in_out='OUTPUT',
                                    socket_type='NodeSocketGeometry', parent=None)  # create OUTPUT socket

    node_group.links.new(group_input.outputs['GeometryData'], group_output.inputs['GeometryData'])  # link input and output

    # set location
    group_input.location = Vector((-1.2 * group_input.width, 0))
    group_output.location = Vector((1.2 * 3 * group_output.width, 0))

    # add warning
    warning_text = ""
    chinese = ['zh_CN', 'zh_HANS']
    if bpy.context.preferences.view.language in chinese:
        warning_text = "警告：请在此处修改节点可能导致错误。"
    else:
        warning_text = "WARNING:CHANGE THE NODES HERE MAY CAUSE ERRORS"
    warning = node_group.nodes.new(type='NodeFrame')
    warning.name = 'warning'
    warning.label = warning_text
    warning.width = 600
    warning.height = 60
    warning.location = Vector((0, 2 * warning.height))
    warning.use_custom_color = True
    warning.color = (1, 0, 0)

    # deselect all the node
    for node in node_group.nodes:
        node.select = False

    return node_group

def set_geo_node(node_group, selected_objs):
    '''Add selected objects into node group, and join geo info
    '''
    # add Join Geometry node
    join_geo = node_group.nodes.new(type='GeometryNodeJoinGeometry')
    join_geo.name = 'Join_Geometry'
    join_geo.location = Vector((0, 0))  # set location

    cnt = 1
    for obj in selected_objs:
        obj_info = node_group.nodes.new(type='GeometryNodeObjectInfo')
        obj_info.name = obj.name
        obj_info.label = obj.name
        obj_info.location = Vector((-1.2 * cnt * obj_info.width, -1.2 * obj_info.height))
        obj_info.transform_space = 'RELATIVE'
        obj_info.inputs['Object'].default_value = obj

        if not is_based_on_mesh([obj]):
            obj_info.inputs['As Instance'].default_value = True
            obj.SG.as_instance = True
        else:
            obj_info.inputs['As Instance'].default_value = False

        node_group.links.new(obj_info.outputs['Geometry'], node_group.nodes['Join_Geometry'].inputs['Geometry'])

        cnt += 1
    
    # add set material node
    set_material = node_group.nodes.new(type='GeometryNodeSetMaterial')
    set_material.name = 'Set_Material'
    set_material.location = Vector((1.2 * set_material.width, 0))
    # add switch node
    switch = node_group.nodes.new(type='GeometryNodeSwitch')
    switch.input_type = 'GEOMETRY'
    switch.name = 'Switch'
    switch.inputs['Switch'].default_value = False
    switch.location = Vector((2.4 * switch.width, 0))

    # link the nodes
    node_group.links.new(node_group.nodes['Join_Geometry'].outputs['Geometry'],
                         node_group.nodes['Set_Material'].inputs['Geometry'])
    node_group.links.new(node_group.nodes['Join_Geometry'].outputs['Geometry'],
                         node_group.nodes['Switch'].inputs['False'])
    node_group.links.new(node_group.nodes['Set_Material'].outputs['Geometry'],
                         node_group.nodes['Switch'].inputs['True'])
    node_group.links.new(node_group.nodes['Switch'].outputs['Output'],
                         node_group.nodes['Group_Output'].inputs['GeometryData'])
    # deselect all the node
    for node in node_group.nodes:
        node.select = False

def set_parent(parent, children):
    '''Set parent of group member to group object
        and keep transform
    '''
    for child in children:
        matrix_world = child.matrix_world.copy()
        child.parent = parent
        # clear parent_bone
        if child.parent_bone:
            child.parent_bone = ''
        child.matrix_parent_inverse = parent.matrix_world.inverted()
        # print("parent.matrix_world:", parent.matrix_world)
        child.matrix_world = matrix_world
        # update scene
        bpy.context.view_layer.update()

def clear_parent(children):
    '''Clear parent of group member
        and keep transform
    '''
    for child in children:
        matrix_world = child.matrix_world.copy()
        child.parent = None
        # clear parent_bone
        if child.parent_bone:
            child.parent_bone = ''
        child.matrix_world = matrix_world
        # update scene
        bpy.context.view_layer.update()

def hide_viewport_render(objs):
    '''Hide objects in viewport and render
    '''
    for obj in objs:
        obj.hide_set(True)
        obj.hide_render = True

def show_viewport_render(objs):
    '''Show objects in viewport and render
    '''
    for obj in objs:
        obj.hide_set(False)
        obj.hide_render = False

def is_based_on_mesh(objs):
    '''Check if objects are based on mesh
    '''

    mesh_based_objects = ['MESH', 'CURVE', 'SURFACE', 'FONT', 'META']
    for obj in objs:
        if obj.type not in mesh_based_objects:
            return False
    return True

def get_group_members(group_obj):
    '''Get group members
    '''
    group_member = []
    for pointer in group_obj.SG.group_member_list:
        group_member.append(pointer.object_pointer)

    return group_member

def get_node_group(group_obj):
    '''Get node group
    '''
    return group_obj.SG.node_group

def append_member(node_group, members):
    '''Append member to group node
    '''
    # get all the obj info nodes
    obj_info_nodes = []
    for node in node_group.nodes:
        if node.type == 'OBJECT_INFO':
            obj_info_nodes.append(node)
    # sort the obj info nodes by x location,from big to small
    obj_info_nodes.sort(key=lambda x: x.location.x, reverse=True)

    # add new obj info nodes
    for obj in members:
        # create new node
        obj_info = node_group.nodes.new(type='GeometryNodeObjectInfo')
        obj_info.name = obj.name
        obj_info.label = obj.name
        obj_info.transform_space = 'RELATIVE'
        obj_info.inputs['Object'].default_value = obj
        if not is_based_on_mesh([obj]):
            obj_info.inputs['As Instance'].default_value = True
            obj.SG.as_instance = True
        else:
            obj_info.inputs['As Instance'].default_value = False

        # set location
        loc_y = -1.2 * obj_info.height
        loc_x = -1.2 * obj_info.width
        for node in obj_info_nodes:
            if loc_x == node.location.x:
                loc_x -= 1.2 * obj_info.width
            else:
                break
        obj_info.location = Vector((loc_x, loc_y))
        obj_info_nodes.append(obj_info)

        # connect to join geometry node
        node_group.links.new(obj_info.outputs['Geometry'], node_group.nodes['Join_Geometry'].inputs['Geometry'])

    # deselect all the node
    for node in node_group.nodes:
        node.select = False

def remove_object_info_node(node_group, obj):
    '''Remove object info node
    '''
    for node in node_group.nodes:
        if node.type == "OBJECT_INFO" and node.inputs["Object"].default_value == obj:
            node_group.nodes.remove(node)
            break

def rename_uv_name(obj):
    '''Rename uv name
    '''
    if obj.type != 'MESH':
        return
    cnt = 1
    for uv_layer in obj.data.uv_layers:
        old_uv_name = uv_layer.name
        new_uv_name = "UVMap_" + str(cnt)

        # change all materials' uv map node name
        for material in obj.data.materials:
            if not material:
                continue
            if material.use_nodes:
                nodes = material.node_tree.nodes
                # find the uv map node, update them
                for node in nodes:
                    if node.type == 'UVMAP' and node.uv_map == old_uv_name:
                        node.uv_map = new_uv_name
        uv_layer.name = new_uv_name # rename uv layer
        cnt += 1

def is_group_member_linked(group):
    '''Check if a group's members are linked to scene collection
    '''
    for member in group.SG.group_member_list:
        if len(member.object_pointer.users_collection) == 0:
            return False
    return True


