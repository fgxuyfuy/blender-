import bpy
from bpy.app.handlers import persistent
from SmartGroup.addons.SmartGroup.utils.util import remove_object_info_node, is_group_member_linked


@persistent
def remove_deleted_group_members(scene, depsgraph):
    # check if in edit mode and has edit group object
    if not bpy.context.scene.SG.edit_mode or not bpy.context.scene.SG.edit_group_object:
        return
    
    group_object = bpy.context.scene.SG.edit_group_object
    # get all objects in collection
    all_objs = list(scene.collection.all_objects)

    # if group member is not in collection, remove it from group member list, and remove it from node group
    length = len(group_object.SG.group_member_list)
    node_group = group_object.SG.node_group
    for i in range(length-1, -1, -1):
        obj = group_object.SG.group_member_list[i].object_pointer
        if obj not in all_objs:
            remove_object_info_node(node_group, obj)
            group_object.SG.group_member_list.remove(i)

# if not in edit mode, hide group members
@persistent
def hide_group_members(scene, depsgraph):
    if scene.SG.duplicating:
        return
    group_objects = []
    for obj in scene.collection.all_objects: # get all group objects
        if obj.SG.is_group:
            group_objects.append(obj)
    for obj in group_objects:
        if not is_group_member_linked(obj):
            return
        if scene.SG.edit_group_object != obj:
            for member in obj.SG.group_member_list:
                member.object_pointer.hide_set(True)

# move group members to the collection of the group object
@persistent
def keep_collection_with_group_object(scene, depsgraph):
    # get all group objects
    group_objects = []
    for obj in scene.collection.all_objects:
        if obj.SG.is_group:
            group_objects.append(obj)

    for group_object in group_objects:
        if not group_object.users_collection:
            continue
        group_users_collection = list(group_object.users_collection)
        for member in group_object.SG.group_member_list:
            flag = False
            if len(member.object_pointer.users_collection) == 0:
                continue
            for col in member.object_pointer.users_collection:
                if col in group_users_collection:
                    flag = True
                    break
            if flag:
                continue
            if member.object_pointer.users_collection[0] != group_object.users_collection[0]:
                source_collection = member.object_pointer.users_collection[0]
                target_collection = group_object.users_collection[0]
                target_collection.objects.link(member.object_pointer)
                source_collection.objects.unlink(member.object_pointer)


