import bpy

from SmartGroup.addons.SmartGroup.config import __addon_name__
from SmartGroup.addons.SmartGroup.preference.AddonPreferences import SmartGroupAddonPreferences
from SmartGroup.addons.SmartGroup.utils.util import get_bbox_center, new_GeometryNodes_group, set_geo_node, set_parent, \
    hide_viewport_render, is_based_on_mesh, get_group_members, show_viewport_render, clear_parent, get_node_group, \
    append_member, rename_uv_name, is_group_member_linked


class CreateGroupOperator(bpy.types.Operator):
    bl_idname = "object.create_group"
    bl_label = "Create Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Create a Group with Selected Objects"

    show_bounds: bpy.props.BoolProperty(name="Show Bounds", default=True)
    bounds_types: bpy.props.EnumProperty(
        name="Bounds Types", items=[
            ("BOX", "Box", "Box"),
            ("SPHERE", "Sphere", "Sphere"),
            ("CAPSULE", "Capsule", "Capsule"),
            ("CONE", "Cone", "Cone"),
            ("CYLINDER", "Cylinder", "Cylinder"),
        ],
        default="BOX"
    )
    @classmethod
    def poll(cls, context: bpy.types.Context):
        return len(context.selected_objects) > 0 and context.mode == 'OBJECT'

    def execute(self, context: bpy.types.Context):
        addon_preference = bpy.context.preferences.addons[__addon_name__].preferences
        assert isinstance(addon_preference, SmartGroupAddonPreferences)

        group_member = context.selected_objects

        # if selected objects have group, return error
        for obj in context.selected_objects:
            if obj.SG.is_group:
                self.report({'ERROR'}, "Selected objects has group, please select objects without group")
                return {'CANCELLED'}

        # report warning if there are not mesh based objects in the selection
        if not is_based_on_mesh(group_member):
            self.report({'WARNING'}, "There are objects that are not mesh based, addon won't work properly on these objects")

        # create an empty mesh data
        empty_mesh = bpy.data.meshes.new(name="EmptyMesh")

        # create group object
        group_obj = bpy.data.objects.new(name="SmartGroup", object_data=empty_mesh)

        # link the group object to the current collection
        bpy.context.collection.objects.link(group_obj)

        # set location of the group object
        group_obj.location = get_bbox_center(group_member)

        # update scene
        bpy.context.view_layer.update()

        # create new GeometryNodes group, and set the GeometryNodes
        node_group = new_GeometryNodes_group()
        set_geo_node(node_group, group_member)

        # add GeometryNodes modifier to group object, and set modifier's group node
        group_obj.modifiers.new(name="SmartGroup", type='NODES')
        group_obj.modifiers[-1].node_group = node_group
        # hide node group on modifier
        group_obj.modifiers[-1].show_group_selector = False
        # add weighted normal modifier to group object
        if addon_preference.add_weighted_normal_modifier:
            group_obj.modifiers.new(name="WeightedNormal", type='WEIGHTED_NORMAL')
            group_obj.modifiers[-1].keep_sharp = True
            try:
                group_obj.modifiers[-1].use_pin_to_last = True
            except:
                pass

        #set parent
        set_parent(group_obj, group_member)
        # rename uv name
        for obj in group_member:
            rename_uv_name(obj)
        # hide group member viewport, render
        hide_viewport_render(group_member)

        # deselect group member, set the group object as active
        for obj in group_member:
            obj.select_set(False)
        group_obj.select_set(True)
        bpy.context.view_layer.objects.active = group_obj

        # show bounds
        group_obj.show_bounds = self.show_bounds
        group_obj.display_bounds_type = self.bounds_types

        # set is_group as True
        group_obj.SG.is_group = True
        # add group member list
        for obj in group_member:
            new_obj_pointer = group_obj.SG.group_member_list.add()
            new_obj_pointer.object_pointer = obj
        # set node group
        group_obj.SG.node_group = node_group

        return {'FINISHED'}

class DissolveGroupOperator(bpy.types.Operator):
    bl_idname = "object.dissolve_group"
    bl_label = "Dissolve Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Dissolve Selected Groups"

    use_input_selection: bpy.props.BoolProperty(name="Use Input Selection", default=False, options = {'HIDDEN'})
    input_obj_name: bpy.props.StringProperty(name="Input Object Name", default="", options = {'HIDDEN'})
    select_member: bpy.props.BoolProperty(name="Select Member", default=True, options = {'HIDDEN'})
    show_viewport_render: bpy.props.BoolProperty(name="Show Viewport Render", default=True, options = {'HIDDEN'})
    add_to_group: bpy.props.BoolProperty(name="Add to Group", default=False, options = {'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context):
        # if there is a group's member not linked to the scene in the selected objects, report an error
        for obj in context.selected_objects:
            if obj.SG.is_group and not is_group_member_linked(obj):
                self.report({'ERROR'}, "Group's members are not all linked to the scene, operation cancelled.")
                return {'CANCELLED'}

        no_group = True

        if self.use_input_selection:
            obj_list = [bpy.data.objects[self.input_obj_name]]
        else:
            obj_list = context.selected_objects

        for obj in obj_list:
            if not obj.SG.is_group: # if object is not a group, skip
                continue

            group_obj = obj
            group_member = get_group_members(group_obj)
            node_group = get_node_group(group_obj)

            # clear group member list
            group_obj.SG.group_member_list.clear()

            # set member's as-instance to false
            if not self.add_to_group:
                for member in group_member:
                    member.SG.as_instance = False

            # show group member viewport, render
            if self.show_viewport_render:
                show_viewport_render(group_member)

            # clear parent
            clear_parent(group_member)

            # remove group object and node group
            bpy.data.objects.remove(group_obj)
            bpy.data.node_groups.remove(node_group)

            # select group member
            if self.select_member:
                for obj in group_member:
                    obj.select_set(True)

            no_group = False

        # if there is no group in selection, report an error
        if no_group:
            self.report({'INFO'}, "No group selected")
            return {'CANCELLED'}
        return {'FINISHED'}

class AddSelectionToGroupOperator(bpy.types.Operator):
    bl_idname = "object.add_selection_to_group"
    bl_label = "Add Selection to Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Add Selected Objects to Group"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and (context.active_object or context.scene.SG.edit_mode)

    def execute(self, context):
        # if active object is not a group, report an error
        if not context.active_object:
            pass
        elif not context.active_object.SG.is_group and not context.scene.SG.edit_mode:
            self.report({'ERROR'}, "Active object is not a group")
            return {'CANCELLED'}
        # if there is a group's member not linked to the scene in the selected objects, report an error
        for obj in context.selected_objects:
            if obj.SG.is_group and not is_group_member_linked(obj):
                self.report({'ERROR'}, "Group's members are not all linked to the scene, operation cancelled.")
                return {'CANCELLED'}

        # report warning if there are objects that are not based in the selection
        if not is_based_on_mesh(context.selected_objects):
            self.report({'WARNING'}, "There are objects that are not mesh based, addon won't work properly on these objects")

        if context.scene.SG.edit_mode:
            group_obj = context.scene.SG.edit_group_object
        else:
            group_obj = context.active_object
        node_group = get_node_group(group_obj)

        cnt = 0
        # if selected objects is a group, dissolve group then add the members to the group obj
        selection = context.selected_objects
        for obj in selection:
            if obj == group_obj: # if object is the group object, skip
                continue
            group_members = get_group_members(group_obj) # if object in the group member list, skip
            if obj in group_members:
                continue
            if obj.SG.is_group:
                group_member = get_group_members(obj) # get group members
                # print(obj.name)
                # dissolve the group
                bpy.ops.object.dissolve_group(use_input_selection=True, input_obj_name=obj.name, select_member=False, show_viewport_render=False, add_to_group=True)

                set_parent(group_obj, group_member) # set parent

                for obj in group_member: # append member to list
                    new_obj_pointer = group_obj.SG.group_member_list.add()
                    new_obj_pointer.object_pointer = obj
                    # if edit mode, show viewport
                    if context.scene.SG.edit_mode:
                        obj.hide_set(False)
                # append member to node group
                append_member(node_group, group_member)
                cnt += 1
            else:
                rename_uv_name(obj) # rename uv name
                set_parent(group_obj, [obj]) # set parent
                # hide viewport render
                if not context.scene.SG.edit_mode:
                    hide_viewport_render([obj])
                else:
                    obj.hide_render = True
                new_obj_pointer = group_obj.SG.group_member_list.add()
                new_obj_pointer.object_pointer = obj
                append_member(node_group, [obj])

        return {'FINISHED'}

class DeleteGroupOperator(bpy.types.Operator):
    bl_idname = "object.delete_group"
    bl_label = "Delete Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Delete Selected Groups"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context):
        # if there is a group's member not linked to the scene in the selected objects, report an error
        for obj in context.selected_objects:
            if obj.SG.is_group and not is_group_member_linked(obj):
                self.report({'ERROR'}, "Group's members are not all linked to the scene, operation cancelled.")
                return {'CANCELLED'}

        no_group = True

        # get group objs' name from selected objects
        group_objs_name = []
        for obj in context.selected_objects:
            if not obj.SG.is_group:
                continue
            else:
                group_objs_name.append(obj.name)
                no_group = False

        # if there is no group in selection, report an error
        if no_group:
            self.report({'INFO'}, "No group selected")
            return {'CANCELLED'}

        for name in group_objs_name:
            # remove node group
            bpy.data.node_groups.remove(bpy.data.objects[name].SG.node_group)
            
            # remove group member
            group_members = get_group_members(bpy.data.objects[name])
            group_members_name = []
            for member in group_members:
                group_members_name.append(member.name)
            for member_name in group_members_name:
                bpy.data.objects.remove(bpy.data.objects[member_name])

            # remove group object
            bpy.data.objects.remove(bpy.data.objects[name])

        return {'FINISHED'}

class ApplyGroupOperator(bpy.types.Operator):
    bl_idname = "object.apply_group"
    bl_label = "Apply Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply the SmartGroup Modifier and Remove Group Members.(The Group Object will be one Object, instance won't be applied)"

    apply_other_modifiers: bpy.props.BoolProperty(
        name="Apply Other Modifiers",
        description="Apply other modifiers on the group objects",
        default=False
    )
    show_bounds: bpy.props.BoolProperty(name="Show Bounds", default=False)

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        # if there is a group's member not linked to the scene in the selected objects, report an error
        for obj in context.selected_objects:
            if obj.SG.is_group and not is_group_member_linked(obj):
                self.report({'ERROR'}, "Group's members are not all linked to the scene, operation cancelled.")
                return {'CANCELLED'}

        # Get all selected group objects
        group_objects = [obj for obj in context.selected_objects if obj.SG.is_group]
        
        if not group_objects:
            self.report({'INFO'}, "No group selected")
            return {'CANCELLED'}

        for group_obj in group_objects:
            # Find SmartGroup modifier
            smart_group_mod = None
            for mod in group_obj.modifiers:
                if mod.type == 'NODES' and mod.node_group == group_obj.SG.node_group:
                    smart_group_mod = mod
                    break

            if not smart_group_mod:
                self.report({'WARNING'}, f"SmartGroup modifier not found on {group_obj.name}")
                continue

            # Apply SmartGroup modifier first
            try:
                # Ensure current object is active
                context.view_layer.objects.active = group_obj
                bpy.ops.object.modifier_apply(modifier=smart_group_mod.name)
            except:
                self.report({'WARNING'}, f"Could not apply SmartGroup modifier on {group_obj.name}")
                continue

            # Apply other modifiers
            if self.apply_other_modifiers and len(group_obj.modifiers) > 1:
                for mod in group_obj.modifiers:
                    try:
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                    except:
                        self.report({'WARNING'}, f"Could not apply modifier: {mod.name} on {group_obj.name}")

            # Get and remove group members
            group_members = get_group_members(group_obj)
            for member in group_members:
                bpy.data.objects.remove(member, do_unlink=True)

            # Clear group properties
            group_obj.SG.is_group = False
            group_obj.SG.group_member_list.clear()
            
            # Remove node group
            if group_obj.SG.node_group:
                bpy.data.node_groups.remove(group_obj.SG.node_group)
                group_obj.SG.node_group = None
            # set bounding box
            group_obj.show_bounds = self.show_bounds
        return {'FINISHED'}

class DuplicateGroupOperator(bpy.types.Operator):
    bl_idname = "object.duplicate_group"
    bl_label = "Duplicate Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Duplicate Selected Groups"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        # if there is a group's member not linked to the scene in the selected objects, report an error
        for obj in context.selected_objects:
            if obj.SG.is_group and not is_group_member_linked(obj):
                self.report({'ERROR'}, "Group's members are not all linked to the scene, operation cancelled.")
                return {'CANCELLED'}

        context.scene.SG.duplicating = True
        group_objects = []
        for obj in context.selected_objects:
            if obj.SG.is_group:
                group_objects.append(obj)
        if not group_objects:
            self.report({'INFO'}, "No group selected")
            return {'CANCELLED'}
        # show all group members
        for group_object in group_objects:
            group_members = get_group_members(group_object)
            for member in group_members:
                member.hide_set(False)

        # duplicate groups
        new_group_objects = []
        bpy.ops.object.select_all(action='DESELECT')  # deselect all objects
        for group_object in group_objects: # select group objects and members
            group_object.select_set(True)
            members = get_group_members(group_object)
            for member in members:
                member.select_set(True)
        bpy.ops.object.duplicate_move() # duplicate
        # get new group objects
        for obj in context.selected_objects:
            if obj.SG.is_group:
                new_group_objects.append(obj)

        # change group member list for new group objects
        for obj in new_group_objects:
            children = obj.children
            group_members = [member for member in children if not member.SG.is_group]
            obj.SG.group_member_list.clear()
            for member in group_members:
                new_obj_pointer = obj.SG.group_member_list.add()
                new_obj_pointer.object_pointer = member

        # set new node group for new group objects
        for obj in new_group_objects:
            group_members = get_group_members(obj)
            # create new GeometryNodes group, and set the GeometryNodes
            node_group = new_GeometryNodes_group()
            obj.SG.node_group = node_group
            set_geo_node(node_group, group_members)
            obj.modifiers['SmartGroup'].node_group = node_group
        context.scene.SG.duplicating = False

        bpy.ops.object.select_all(action='DESELECT')  # deselect all objects
        # select all new group objects
        for obj in new_group_objects:
            obj.select_set(True)
        bpy.ops.transform.translate('INVOKE_DEFAULT')
        print('new_group:', len(new_group_objects))
        return {'FINISHED'}
    
class FixGroupOperator(bpy.types.Operator):
    bl_idname = "object.fix_group"
    bl_label = "Fix Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Fix Selected Groups(Use it when there are Problems in Materials or Parenting)"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and (context.selected_objects or context.scene.SG.edit_mode)

    def execute(self, context):
        # if there is a group's member not linked to the scene in the selected objects, report an error
        for obj in context.selected_objects:
            if obj.SG.is_group and not is_group_member_linked(obj):
                self.report({'ERROR'}, "Group's members are not all linked to the scene, operation cancelled.")
                return {'CANCELLED'}

        group_objects = []
        edit = False

        if context.scene.SG.edit_mode:
            group_objects.append(context.scene.SG.edit_group_object)
            edit = True
        else:
            for obj in context.selected_objects:
                if obj.SG.is_group:
                    group_objects.append(obj)
        if not group_objects:
            self.report({'INFO'}, "No group selected")
            return {'CANCELLED'}
        
        # if group members' type is MESH, remove them from group, and re-add them to group
        if edit:
            objects_list = []
            group_members = get_group_members(group_objects[0])
            for member in group_members:
                if member.type == 'MESH':
                    objects_list.append(member)

            context_override = context.copy()
            context_override['selected_objects'] = objects_list
            with context.temp_override(**context_override):
                bpy.ops.smartgroup.remove_group_member()
                bpy.ops.object.add_selection_to_group()
        else:
            for group_object in group_objects:
                context_override_01 = context.copy()
                context_override_01['active_object'] = group_object
                context_override_01['selected_objects'] = [group_object]
                with context.temp_override(**context_override_01):
                    bpy.ops.smartgroup.edit_group()
                    context_override_02 = context_override_01.copy()
                    objects_list = []
                    group_members = get_group_members(group_object)
                    for member in group_members:
                        if member.type == 'MESH':
                            objects_list.append(member)
                    context_override_02['selected_objects'] = objects_list
                    with context.temp_override(**context_override_02):
                        bpy.ops.smartgroup.remove_group_member()
                        bpy.ops.object.add_selection_to_group()
                    bpy.ops.smartgroup.exit_edit_group()

        # if group member's parent is not group object, set parent
        if edit:
            group_members = get_group_members(group_objects[0])
            for member in group_members:
                if member.parent != group_objects[0]:
                    set_parent(group_objects[0], [member])
        else:
            for group_object in group_objects:
                group_members = get_group_members(group_object)
                for member in group_members:
                    if member.parent != group_object:
                        set_parent(group_object, [member])

        # if group members' polygons are not assigned with materials, assign them with default material(first material in material slot)
        if edit:
            group_members = get_group_members(group_objects[0])
            for member in group_members:
                if member.type != 'MESH':
                    continue
                for polygon in member.data.polygons:
                    if polygon.material_index == 0:
                        continue
                    if polygon.material_index >= len(member.material_slots) or member.material_slots[polygon.material_index].material is None:
                        polygon.material_index = 0
        else:
            for group_object in group_objects:
                group_members = get_group_members(group_object)
                for member in group_members:
                    if member.type != 'MESH':
                        continue
                    for polygon in member.data.polygons:
                        if polygon.material_index == 0:
                            continue
                        if polygon.material_index >= len(member.material_slots) or member.material_slots[polygon.material_index].material is None:
                            polygon.material_index = 0
        self.report({'INFO'}, "Groups fixed")
        return {'FINISHED'}
