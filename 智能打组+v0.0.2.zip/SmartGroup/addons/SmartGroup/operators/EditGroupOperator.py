import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from SmartGroup.addons.SmartGroup.utils.util import clear_parent, get_group_members, get_node_group, remove_object_info_node, \
    is_group_member_linked

from SmartGroup.addons.SmartGroup.config import __addon_name__
from SmartGroup.addons.SmartGroup.preference.AddonPreferences import SmartGroupAddonPreferences

def draw_group_bounds(context):
    """Draw group bounds in edit mode"""
    if not context.scene.SG.edit_mode or not context.scene.SG.edit_group_object:
        return
    
    # Get the editing group object
    group_obj = context.scene.SG.edit_group_object
    
    # Get the bound box corners in world space
    world_corners = [group_obj.matrix_world @ Vector(corner) for corner in group_obj.bound_box]
    
    # Define the indices for the lines that make up the box
    indices = [(0, 1), (1, 2), (2, 3), (3, 0),  # Bottom face
              (4, 5), (5, 6), (6, 7), (7, 4),  # Top face
              (0, 4), (1, 5), (2, 6), (3, 7)]  # Vertical edges
    
    # Create vertices list for the lines
    vertices = []
    for i1, i2 in indices:
        vertices.extend([world_corners[i1], world_corners[i2]])
    
    # Set up shader
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    
    # Create batch
    batch = batch_for_shader(shader, 'LINES', {"pos": vertices})
    
    # Draw the box
    shader.bind()
    shader.uniform_float("color", (0.0, 0.8, 0.0, 1.0))  # Green color
    gpu.state.line_width_set(2.0)  # Set line width
    batch.draw(shader)
    gpu.state.line_width_set(1.0)  # Reset line width

class EditGroupOperator(bpy.types.Operator):
    bl_idname = "smartgroup.edit_group"
    bl_label = "Edit Group"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Edit active Group"

    _handle = None  # Store the draw handler

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.SG.is_group

    def execute(self, context):
        # if there is a group's member not linked to the scene in the selected objects, report an error
        for obj in context.selected_objects:
            if obj.SG.is_group and not is_group_member_linked(obj):
                self.report({'ERROR'}, "Group's members are not all linked to the scene, operation cancelled.")
                return {'CANCELLED'}

        addon_preference = bpy.context.preferences.addons[__addon_name__].preferences
        assert isinstance(addon_preference, SmartGroupAddonPreferences)

        scene = context.scene
        scene.SG.edit_mode = True
        # Set the editing group object
        editing_group_object = context.active_object
        scene.SG.edit_group_object = editing_group_object
        
        # Set the edit object properties
        scene.SG.edit_object_show_wire = editing_group_object.show_wire
        scene.SG.edit_object_show_bounds = editing_group_object.show_bounds
        scene.SG.edit_object_show_in_front = editing_group_object.show_in_front
        scene.SG.edit_object_alpha = editing_group_object.color[3]
        scene.SG.edit_object_display_type = editing_group_object.display_type
        scene.SG.scene_color_type = context.space_data.shading.color_type

        editing_group_object.show_wire = addon_preference.show_wire
        editing_group_object.show_bounds = False
        editing_group_object.show_in_front = addon_preference.show_in_front
        editing_group_object.color[3] = addon_preference.transparency
        context.space_data.shading.color_type = "OBJECT"

        # Show group members
        for member in editing_group_object.SG.group_member_list:
            member.object_pointer.hide_set(False)
            member.object_pointer.select_set(True)

        # use local view
        if context.scene.SG.use_local_view and not context.space_data.local_view:
            bpy.ops.view3d.localview(frame_selected=False)
            # deselect all objects
            bpy.ops.object.select_all(action='DESELECT')

        editing_group_object.hide_select = True

        editing_group_object.hide_viewport = addon_preference.hide_group

        # Add draw handler
        if EditGroupOperator._handle is None:
            EditGroupOperator._handle = bpy.types.SpaceView3D.draw_handler_add(
                draw_group_bounds, (context,), 'WINDOW', 'POST_VIEW'
            )
            # Force viewport update
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        return {'FINISHED'}
    
class ExitEditGroupOperator(bpy.types.Operator):
    bl_idname = "smartgroup.exit_edit_group"
    bl_label = "Exit Edit Mode"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Exit Edit Mode"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.scene.SG.edit_mode

    def execute(self, context):
        scene = context.scene
        scene.SG.edit_mode = False

        # Get the editing group object
        editing_group_object = scene.SG.edit_group_object
        # Hide group members
        for member in editing_group_object.SG.group_member_list:
            member.object_pointer.hide_set(True)
        # set the edit object properties
        editing_group_object.show_wire = scene.SG.edit_object_show_wire
        editing_group_object.show_bounds = scene.SG.edit_object_show_bounds
        editing_group_object.show_in_front = scene.SG.edit_object_show_in_front
        editing_group_object.color[3] = scene.SG.edit_object_alpha
        editing_group_object.hide_select = False
        editing_group_object.display_type = scene.SG.edit_object_display_type
        context.space_data.shading.color_type = scene.SG.scene_color_type
        # delete all objects, set group object as active
        bpy.ops.object.select_all(action='DESELECT')
        editing_group_object.select_set(True)
        context.view_layer.objects.active = editing_group_object

        scene.SG.edit_object_show_wire = False
        scene.SG.edit_object_show_bounds = False
        scene.SG.edit_object_show_in_front = False
        scene.SG.edit_object_alpha = 1.0
        scene.SG.scene_color_type = "OBJECT"
        scene.SG.edit_object_display_type = "TEXTURED"
        scene.SG.edit_group_object.hide_viewport = False
        
        # Clear the editing group object
        scene.SG.edit_group_object = None

        # Remove draw handler
        if EditGroupOperator._handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(EditGroupOperator._handle, 'WINDOW')
            EditGroupOperator._handle = None
            # Force viewport update
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        if context.space_data.local_view:
            bpy.ops.view3d.localview(frame_selected=False)
        return {'FINISHED'}
    
class RemoveGroupMemberOperator(bpy.types.Operator):
    bl_idname = "smartgroup.remove_group_member"
    bl_label = "Remove Selected Group Members"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Remove Selected Group Members"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.scene.SG.edit_mode and context.selected_objects
    
    def execute(self, context):
        # filter out the group members from the selected objects
        removing_objects = []
        editing_group = context.scene.SG.edit_group_object
        group_members = get_group_members(editing_group)
        for obj in context.selected_objects:
            if obj in group_members:
                removing_objects.append(obj)
        if not removing_objects:
            self.report({'INFO'}, "No group members selected")
            return {'CANCELLED'}
        # remove the selected objects from the group members list
        length = len(editing_group.SG.group_member_list)
        for i in range(length-1, -1, -1):
            if editing_group.SG.group_member_list[i].object_pointer in removing_objects:
                editing_group.SG.group_member_list.remove(i)
        # remove object info nodes from the node group
        node_group = get_node_group(editing_group)
        for obj in removing_objects:
            remove_object_info_node(node_group, obj)
        # show render
        for obj in removing_objects:
            obj.hide_render = False
        # clear parent
        clear_parent(removing_objects)
        # set as-instance status to False
        for obj in removing_objects:
            obj.SG.as_instance = False
        return {'FINISHED'}
    
class SwitchDisplayTypeOperator(bpy.types.Operator):
    bl_idname = "smartgroup.switch_display_type"
    bl_label = "Switch Display Type"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Switch Display Type"

    @classmethod
    def poll(cls, context):
        return context.scene.SG.edit_mode

    def execute(self, context):
        editing_group = context.scene.SG.edit_group_object
        if editing_group.display_type != "WIRE":
            editing_group.display_type = "WIRE"
            editing_group.show_in_front = False
        else:
            editing_group.display_type = "SOLID"
            editing_group.show_in_front = True
        return {'FINISHED'}

class SelectAllGroupMembersOperator(bpy.types.Operator):
    bl_idname = "smartgroup.select_all_group_members"
    bl_label = "Select All Group Members"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Select All Group Members"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.scene.SG.edit_mode

    def execute(self, context):
        # deselect all objects
        bpy.ops.object.select_all(action='DESELECT')
        # select all group members
        editing_group = context.scene.SG.edit_group_object
        for member in editing_group.SG.group_member_list:
            member.object_pointer.select_set(True)
        return {'FINISHED'}

class RemoveFromLocalViewOperator(bpy.types.Operator):
    bl_idname = "smartgroup.remove_from_local_view"
    bl_label = "Remove From Local View"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Remove Selected Objects from Local View"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.scene.SG.edit_mode and context.space_data.local_view and context.selected_objects

    def execute(self, context):
        bpy.ops.view3d.localview_remove_from()
        return {'FINISHED'}

class MembersInstanceSwitchOperator(bpy.types.Operator):
    bl_idname = "object.members_instance_switch"
    bl_label = "Members Instance Switch"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Switch Selected Group Members to Instance/Non-Instance"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        # get groups from selected objects
        group_object = context.scene.SG.edit_group_object
        selected_members = []
        members = get_group_members(group_object)
        for obj in context.selected_objects:
            if obj in members:
                selected_members.append(obj)
        # switch instance status
        node_group = group_object.SG.node_group
        for obj in selected_members:
            obj.SG.as_instance = not obj.SG.as_instance
            for node in node_group.nodes:
                if node.type == 'OBJECT_INFO' and node.inputs['Object'].default_value == obj:
                    node.inputs['As Instance'].default_value = obj.SG.as_instance
                    break

        self.report({'INFO'}, "Group Members instance switched")
        return {'FINISHED'}
