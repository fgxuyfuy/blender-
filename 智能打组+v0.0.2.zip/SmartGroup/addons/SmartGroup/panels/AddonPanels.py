import bpy

from SmartGroup.addons.SmartGroup.config import __addon_name__
from SmartGroup.addons.SmartGroup.operators.GroupOperators import CreateGroupOperator, DissolveGroupOperator, \
    AddSelectionToGroupOperator, DeleteGroupOperator, ApplyGroupOperator, DuplicateGroupOperator, \
    FixGroupOperator
from SmartGroup.addons.SmartGroup.operators.EditGroupOperator import EditGroupOperator, ExitEditGroupOperator, \
    RemoveGroupMemberOperator, SwitchDisplayTypeOperator, SelectAllGroupMembersOperator, RemoveFromLocalViewOperator, \
    MembersInstanceSwitchOperator
from SmartGroup.common.i18n.i18n import i18n


class SmartGroupAddonPanel(bpy.types.Panel):
    bl_label = "Smart Group"
    bl_idname = "VIEW3D_PT_smart_group"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    # name of the side panel
    bl_category = "SmartGroup"

    def draw(self, context: bpy.types.Context):
        # draw the group operator
        layout = self.layout
        if context.scene.SG.edit_mode:
            # draw ops in edit mode
            layout.operator(ExitEditGroupOperator.bl_idname, icon="LOOP_BACK")
            layout.operator(RemoveGroupMemberOperator.bl_idname, icon="REMOVE")
            layout.operator(SelectAllGroupMembersOperator.bl_idname, icon="RESTRICT_SELECT_OFF")
            layout.operator(AddSelectionToGroupOperator.bl_idname, icon="PLUS")
            layout.operator(FixGroupOperator.bl_idname, icon="MODIFIER_DATA")
            layout.operator(RemoveFromLocalViewOperator.bl_idname, icon="RESTRICT_VIEW_OFF")
            layout.operator(MembersInstanceSwitchOperator.bl_idname, icon="OUTLINER_OB_GROUP_INSTANCE", text='Use Instance/Non-Instance')
            # draw display settings
            box = layout.box()
            box.label(text="Display Settings", icon='RESTRICT_VIEW_OFF')
            col = box.column()
            col.prop(context.scene.SG.edit_group_object, 'hide_viewport', text="Hide/Show Group", icon='HIDE_OFF')
            col.prop(context.scene.SG.edit_group_object, 'show_wire', text="Show Wire", icon='MESH_CUBE')
            # draw wire/solid switch
            if context.scene.SG.edit_group_object.display_type != "WIRE":
                col.operator(SwitchDisplayTypeOperator.bl_idname,text="Display as Wire", icon="SHADING_WIRE")
            else:
                col.operator(SwitchDisplayTypeOperator.bl_idname,text="Display as Solid", icon="SHADING_SOLID")
            # draw transparency slider
            col.prop(context.scene.SG.edit_group_object, 'color', index=3, text="Transparency", slider=True)

            # draw instance status
            if context.active_object:
                box = layout.box()
                row = box.row(align=True)
                row.alignment = 'LEFT'
                row.label(text="Status:", icon='MONKEY')
                status = "Instance" if context.active_object.SG.as_instance else "Non-Instance"
                row.label(text=status)
        else:
            layout.operator(CreateGroupOperator.bl_idname, icon="LINKED")
            layout.operator(DissolveGroupOperator.bl_idname, icon="UNLINKED")
            layout.operator(AddSelectionToGroupOperator.bl_idname, icon="PLUS")
            layout.operator(DeleteGroupOperator.bl_idname, icon="TRASH")
            layout.operator(ApplyGroupOperator.bl_idname, icon="MODIFIER_DATA")
            layout.operator(DuplicateGroupOperator.bl_idname, icon="DUPLICATE")
            layout.operator(EditGroupOperator.bl_idname, icon="EDITMODE_HLT")
            layout.operator(FixGroupOperator.bl_idname, icon="MODIFIER_DATA")

        # Draw material override properties and show bounds if active object is a group
        active_obj = context.active_object
        if active_obj and active_obj.SG.is_group and not context.scene.SG.edit_mode:
            # Add separator
            layout.separator()
            box = layout.box()
            box.label(text="Edit Setting", icon='EDITMODE_HLT')
            col = box.column()
            col.prop(context.scene.SG,'use_local_view', text="Use Local View When Editing a Group")
            # get the node group
            node_group = active_obj.SG.node_group
            box = layout.box()
            box.label(text="Show Bounds", icon='MESH_CUBE')
            col = box.column()
            col.prop(active_obj, 'show_bounds', text="Show Bounds")
            col.prop(active_obj, 'display_bounds_type', text="Bounds Type")

            # Create a box for material override settings
            box = layout.box()
            box.label(text="Material Override", icon='MATERIAL')
            
            # Add material override toggle
            col = box.column()
            col.prop(node_group.nodes['Switch'].inputs['Switch'], 'default_value', text="Material Override")
            
            # Add material selection
            col = box.column()
            col.prop(node_group.nodes["Set_Material"].inputs['Material'], 'default_value', text="Material")
        

