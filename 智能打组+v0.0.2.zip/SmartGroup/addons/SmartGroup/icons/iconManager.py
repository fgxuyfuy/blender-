import bpy
import bpy.utils.previews
import os

all_icons = {
    'blender_market_icon': 'blender_market.png',
    'bilibili_icon': 'bilibili.png',
}

loaded_icons = {}

def load_icons():
    for key in all_icons:
        icon_path = os.path.join(os.path.dirname(__file__), 'resources', all_icons[key])
        icons_coll = bpy.utils.previews.new()
        icons_coll.load(key, icon_path, 'IMAGE')
        loaded_icons[key] = icons_coll

def clear_icons():
    for key in loaded_icons:
        bpy.utils.previews.remove(loaded_icons[key])

def get_icon(key):
    return loaded_icons[key][key].icon_id