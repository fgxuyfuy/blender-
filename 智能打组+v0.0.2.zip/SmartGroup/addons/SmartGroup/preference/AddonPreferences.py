import bpy
from bpy.props import BoolProperty, FloatProperty
import rna_keymap_ui
from SmartGroup.addons.SmartGroup.config import __addon_name__
from SmartGroup.addons.SmartGroup.icons.iconManager import get_icon


def get_hotkey_entry_item(km, kmi_name, kmi_value):
    '''
    returns hotkey of specific type, with specific properties.name (keymap is not a dict, so referencing by keys is not enough
    if there are multiple hotkeys!)
    '''
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if km.keymap_items[i].properties.name == kmi_value:
                return km_item
    return None

class SmartGroupAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __addon_name__

    hide_group: BoolProperty(
        name="Hide Group",
        default=True
    )
    show_wire: BoolProperty(
        name="Show Wire",
        default=False
    )
    transparency: FloatProperty(
        name="Transparency",
        default=0.2,
        min=0.0,
        max=1.0
    )
    show_in_front: BoolProperty(
        name="Show In Front",
        default=True
    )
    add_weighted_normal_modifier: BoolProperty(
        name="Add Weighted Normal Modifier",
        default=True
    )
    tabs: bpy.props.EnumProperty(
        name='Tabs',
        items=[
            ('SETTINGS', 'Settings', 'Settings'),
            ('ABOUT', 'About', 'About'),
        ],
        default='SETTINGS'
    )

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(self, "tabs", expand=True)
        if self.tabs == 'SETTINGS':
            self.draw_setting(context)
        else:
            self.draw_about(context)

    def draw_setting(self, context: bpy.types.Context):
        layout = self.layout
        box = layout.box()
        box.label(text="Settings")
        col = box.column(align=True)

        row = col.row()
        split = row.split(factor=0.2)
        split.prop(self, "hide_group", toggle=True)
        split.label(text="Hide the Group Object when editing the Group")

        row = col.row()
        split = row.split(factor=0.2)
        split.prop(self, "show_wire", toggle=True)
        split.label(text="Show Wireframe when editing the Group")

        row = col.row()
        split = row.split(factor=0.2)
        split.prop(self, "transparency", slider=True)
        split.label(text="Default Transparency of the Group Object in editing mode")

        row = col.row()
        split = row.split(factor=0.2)
        split.prop(self, "show_in_front", toggle=True)
        split.label(text="Show the Group Object in front of other objects when editing the Group")

        row = box.row()
        split = row.split(factor=0.2)
        split.prop(self, "add_weighted_normal_modifier", toggle=True)
        split.label(text="Add Weighted Normal Modifier when creating the Group")

        box = layout.box()
        box.label(text="KeyMap")

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.user
        km = kc.keymaps['Object Mode']
        kmi = get_hotkey_entry_item(km, 'wm.call_menu_pie', 'VIEW3D_MT_pie_menu')
        if kmi:
            row = box.row()
            row.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi(["ADDON", "USER", "DEFAULT"], kc, km, kmi, row, 0)
        else:
            box.label("No hotkey entry found")

    def draw_about(self, context):
        blender_market = 'https://blendermarket.com/creators/darthmickey'
        bilibili = 'https://space.bilibili.com/674738074?spm_id_from=333.337.0.0'

        layout = self.layout
        layout.label(text="About")
        row = layout.row(align=True)
        row.operator("wm.url_open", text="Blender Market", icon_value=get_icon('blender_market_icon')).url = blender_market
        row.operator("wm.url_open", text="Bilibili", icon_value=get_icon('bilibili_icon')).url = bilibili


