import bpy

from SmartGroup.addons.SmartGroup.config import __addon_name__
from SmartGroup.addons.SmartGroup.i18n.dictionary import dictionary
from SmartGroup.addons.SmartGroup.icons.iconManager import load_icons, clear_icons
from SmartGroup.addons.SmartGroup.menus.AddonMenu import SmartGroupMenu
from SmartGroup.addons.SmartGroup.properties.AddonProperties import SmartGroupObjectPointerProperties, SmartGroupScenePointerProperties

from SmartGroup.common.class_loader import auto_load
from SmartGroup.common.class_loader.auto_load import add_properties, remove_properties
from SmartGroup.common.i18n.dictionary import common_dictionary
from SmartGroup.common.i18n.i18n import load_dictionary

from SmartGroup.addons.SmartGroup.utils.handler import remove_deleted_group_members, hide_group_members, \
    keep_collection_with_group_object

# Add-on info
bl_info = {
    "name": "Smart Group",
    "author": "Darth Mickey",
    "blender": (4, 1, 0),
    "version": (0, 0, 2),
    "description": "a group tool",
    "warning": "",
    "doc_url": "",
    "tracker_url": "",
    "support": "COMMUNITY",
    "category": "3D View"
}

_addon_properties = {
    bpy.types.Object: {
        "SG": bpy.props.PointerProperty(name="SG", type=SmartGroupObjectPointerProperties),
    },
    bpy.types.Scene: {
        "SG": bpy.props.PointerProperty(name="SG", type=SmartGroupScenePointerProperties),
    }
}

_addon_keymaps = []

def register():
    print("registering")
    # Register classes
    auto_load.init()
    auto_load.register()
    add_properties(_addon_properties)
    load_icons()
    
    # Add handler
    bpy.app.handlers.depsgraph_update_post.append(remove_deleted_group_members)
    bpy.app.handlers.depsgraph_update_post.append(hide_group_members)
    bpy.app.handlers.depsgraph_update_post.append(keep_collection_with_group_object)

    # set pie menu keymap
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name="Object Mode", space_type="EMPTY")
    kmi = km.keymap_items.new('wm.call_menu_pie', type='G', value='PRESS', ctrl=True)
    kmi.properties.name = SmartGroupMenu.bl_idname
    _addon_keymaps.append((km, kmi))

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(bl_info["name"]))

def unregister():
    # Internationalization
    bpy.app.translations.unregister(__addon_name__)

    # Remove handler
    if remove_deleted_group_members in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(remove_deleted_group_members)
    if hide_group_members in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(hide_group_members)
    if keep_collection_with_group_object in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(keep_collection_with_group_object)

    # remove pie menu keymap
    wm = bpy.context.window_manager
    if wm.keyconfigs.addon:
        for km, kmi in _addon_keymaps:
            km.keymap_items.remove(kmi)
    _addon_keymaps.clear()

    # unRegister classes
    auto_load.unregister()
    remove_properties(_addon_properties)
    clear_icons()

    print("{} addon is uninstalled.".format(bl_info["name"]))
